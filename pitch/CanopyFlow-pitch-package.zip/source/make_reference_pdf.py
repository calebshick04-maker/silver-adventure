from pathlib import Path
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
import re,html
O=Path('/workspace/output')
pdfmetrics.registerFont(TTFont('DVS','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DVSB','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFontFamily('DVS',normal='DVS',bold='DVSB',italic='DVS',boldItalic='DVSB')
styles=getSampleStyleSheet()
for n in ['Normal','BodyText','Heading1','Heading2','Heading3']:
 styles[n].fontName='DVS';styles[n].textColor=colors.HexColor('#17343C')
styles['BodyText'].fontSize=9;styles['BodyText'].leading=13
styles['Heading1'].fontName='DVSB';styles['Heading1'].fontSize=23;styles['Heading1'].leading=28
styles['Heading2'].fontName='DVSB';styles['Heading2'].fontSize=14;styles['Heading2'].spaceBefore=16
styles.add(ParagraphStyle('smalltable',parent=styles['BodyText'],fontSize=8,leading=11))
def fmt(s):
 s=html.escape(s)
 s=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<a href="\2" color="#087D81">\1</a>',s)
 s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
 return s.replace('`','')
story=[];lines=(O/'judge-prep.md').read_text().splitlines();i=0
while i<len(lines):
 l=lines[i]
 if not l: i+=1;continue
 if l.startswith('|'):
  rows=[]
  while i<len(lines) and lines[i].startswith('|'):
   cells=[s.strip() for s in lines[i].strip('|').split('|')]
   if not all(re.fullmatch(r'[:\- ]+',c) for c in cells):rows.append([Paragraph(fmt(c),styles['smalltable']) for c in cells])
   i+=1
  t=Table(rows,colWidths=[145,120,235],repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#DBEDE2')),('VALIGN',(0,0),(-1,-1),'TOP'),('BOTTOMPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,-1),.3,colors.HexColor('#CDD9D7'))]));story.extend([t,Spacer(1,12)]);continue
 if l.startswith('# '):story.append(Paragraph(fmt(l[2:]),styles['Heading1']))
 elif l.startswith('## '):story.append(Paragraph(fmt(l[3:]),styles['Heading2']))
 else:story.append(Paragraph(fmt(l),styles['BodyText']));story.append(Spacer(1,6))
 i+=1
def footer(c,d):
 c.setFont('DVS',8);c.setFillColor(colors.HexColor('#637977'));c.drawString(44,26,'CANOPYFLOW / JUDGE REFERENCE / ASSUMPTIONS ARE NOT FIELD RESULTS');c.drawRightString(568,26,str(d.page))
SimpleDocTemplate(str(O/'judge-prep.pdf'),pagesize=(612,792),leftMargin=46,rightMargin=46,topMargin=43,bottomMargin=46).build(story,onFirstPage=footer,onLaterPages=footer)
print('Judge PDF complete')
