from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.chart import BarChart,Reference
import textwrap,json,zipfile,os
O=Path('/workspace/output');W=Path('/workspace/work');O.mkdir(exist_ok=True)
BG='#101F25';FG='#F2F1E9';MUT='#A9BDBD';GREEN='#9BE3A3';TEAL='#51CFCA';ORANGE='#FFBA72';PANEL='#1D343C'
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
R=Presentation();R.slide_width= Inches(13.333333);R.slide_height= Inches(7.5)
PDF=canvas.Canvas(str(O/'CanopyFlow-pitch.pdf'),pagesize=(960,540))
SOURCES={
'S1':('USDA ARS | Chen et al., 2013 | apple-orchard trial','https://www.ars.usda.gov/research/publications/publication/?seqNo115=296307'),
'S2':('USDA NASS | Noncitrus Fruits and Nuts 2025 Summary | p. 38','https://release.nass.usda.gov/reports/ncit0526.pdf'),
'S3':('Smart Apply | Vineyards | manufacturer description, not independent testing','https://www.smartapply.com/growers/vineyards'),
'S4':('U.S. EPA | Introduction to Pesticide Labels','https://www.epa.gov/pesticide-labels/introduction-pesticide-labels'),
'S5':('Virginia Tech | Airblast calibration lab | water-only orchard footage','https://www.virginiafruit.ento.vt.edu/airdemo.html'),
'S6':('OMAFA / CropLife Canada | drift education videos, via Sprayers 101','https://sprayers101.com/omafra-drift-video/'),
'S7':('Health Canada | Management of Pesticide Spray Drift','https://www.canada.ca/en/health-canada/services/consumer-product-safety/pesticides-pest-management/growers-commercial-users/drift-mitigation/management-pesticide-spray-drift.html'),
}
notes=[]
def rgb(c):return RGBColor.from_string(c.strip('#'))
class Slide:
 def __init__(self,kicker,title,sub='',source='',note=''):
  self.n=len(R.slides)+1;self.s=R.slides.add_slide(R.slide_layouts[6]);self.s.background.fill.solid();self.s.background.fill.fore_color.rgb=rgb(BG)
  self.im=Image.new('RGB',(1600,900),BG);self.d=ImageDraw.Draw(self.im)
  self.text(kicker.upper(),64,42,20,GREEN,True,1450)
  self.text(title,64,94,51,FG,True,1470)
  if sub:self.text(sub,66,172,23,MUT,False,1450)
  self.rect(64,842,1472,2,'#355057');self.text('CANOPYFLOW  /  WORKING CONCEPT',64,858,15,MUT,width=520)
  self.text(str(self.n).zfill(2),1480,854,20,GREEN,True,60)
  if source:self.text(source,560,860,13,MUT,width=890)
  self.s.notes_slide.notes_text_frame.text=note
  notes.append({'slide':self.n,'title':title,'script':note})
 def rect(self,x,y,w,h,c):
  self.d.rectangle((x,y,x+w,y+h),fill=c)
  sh=self.s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x/120), Inches(y/120), Inches(w/120), Inches(h/120));sh.fill.solid();sh.fill.fore_color.rgb=rgb(c);sh.line.fill.background();return sh
 def text(self,t,x,y,size=28,color=FG,bold=False,width=1400):
  f=ImageFont.truetype(BOLD if bold else FONT,size)
  lines=[]
  for p in t.split('\n'):
   line=''
   for word in p.split():
    if line and self.d.textlength(line+' '+word,font=f)>width:lines.append(line);line=word
    else:line=(line+' '+word).strip()
   lines.append(line)
  height=len(lines)*size*1.38+8
  self.d.multiline_text((x,y),'\n'.join(lines),font=f,fill=color,spacing=int(size*.35))
  box=self.s.shapes.add_textbox(Inches(x/120),Inches(y/120),Inches(width/120),Inches(height/120))
  tf=box.text_frame;tf.word_wrap=False;tf.margin_left=0;tf.margin_top=0;tf.margin_right=0;tf.margin_bottom=0
  for j,line in enumerate(lines):
   p=tf.paragraphs[0] if j==0 else tf.add_paragraph();p.text=line;p.font.name='DejaVu Sans';p.font.size=Pt(size*.6);p.font.bold=bold;p.font.color.rgb=rgb(color);p.space_after=Pt(size*.21)
  return box
 def card(self,x,y,w,label,value,detail='',color=GREEN):
  self.rect(x,y,w,232,PANEL);self.text(label,x+26,y+24,20,MUT,width=w-52);self.text(value,x+26,y+66,47,color,True,w-52)
  self.text(detail,x+26,y+145,21,FG,width=w-52)
 def picture(self,path,x,y,w,h):
  im=Image.open(path).convert('RGB');im=im.resize((int(w),int(h)));self.im.paste(im,(int(x),int(y)));self.s.shapes.add_picture(str(path),Inches(x/120), Inches(y/120),Inches(w/120), Inches(h/120))
 def link(self,label,url,x,y,w=700):
  b=self.text(label+'  ↗',x,y,24,TEAL,True,w);b.text_frame.paragraphs[0].runs[0].hyperlink.address=url
  PDF.linkURL(url,(x*.6,(900-y-42)*.6,(x+w)*.6,(900-y)*.6),relative=0)
 def movie(self,path,poster,x,y,w,h):
  self.picture(poster,x,y,w,h)
  self.s.shapes.add_movie(str(path), Inches(x/120), Inches(y/120), Inches(w/120), Inches(h/120),poster_frame_image=str(poster),mime_type='video/mp4')
 def done(self):
  p=W/f'slide-{self.n:02}.png';self.im.save(p);PDF.drawImage(ImageReader(self.im),0,0,960,540);PDF.showPage()

s=Slide('Precision crop protection','Every gap is a chance to save.','CanopyFlow  •  A camera-guided, tractor-towed vineyard sprayer',note='[0:00–0:20] Every gap in a vine canopy is a chance to save spray. We are developing CanopyFlow: a tractor-towed sprayer that sees foliage, estimates how dense it is, and activates only the fixed spray zones that need treatment. Our goal is lower input cost while preserving crop protection. CanopyFlow is a temporary working name.')
s.text('SEE THE CANOPY.\nMATCH THE SPRAY.',70,285,62,FG,True,820)
s.text('Three fixed zones. One chemical at a time.\nA farm-funded path to field validation.',73,505,29,MUT,width=780)
s.rect(1060,280,420,405,PANEL)
for i,(v,l) in enumerate([(0.8,'UPPER  /  DENSE'),(.45,'MIDDLE  /  LIGHT'),(0,'LOWER  /  GAP')]):
 y=320+i*110;s.text(l,1090,y,20,FG,True,350);s.rect(1090,y+43,340,16,'#355057');s.rect(1090,y+43,max(1,340*v),16,GREEN if v else ORANGE)
s.text('Illustrative detection states',1085,722,17,MUT,width=420);s.done()

s=Slide('01 / The customer problem','Spraying empty space still costs money.','Canopy gaps and uneven growth make a constant output a poor match.',source='Evidence: S1, S5, S7  |  Footage is illustrative, not a waste measurement.',note='[0:20–0:45] A fixed output can keep spraying through gaps and above or below the plant target. That means purchased material may not reach the intended canopy. [Play a short portion of the embedded water-only calibration demonstration.] This is orchard calibration footage from Virginia Tech, not our machine or a measurement of a vineyard waste percentage. Good calibration already reduces waste; we must improve on a properly calibrated baseline.')
s.text('The farm pays for:',70,280,31,GREEN,True,570)
s.text('Chemical sent off target\nWater, mixing and refills\nUncertainty about where spray went',70,350,29,FG,width=600)
if (O/'airblast-excerpt.mp4').exists():s.movie(O/'airblast-excerpt.mp4',O/'airblast-poster.png',745,270,790,445)
else:s.rect(745,270,790,445,PANEL);s.text('REAL-WORLD FOOTAGE\nWater-only orchard calibration',785,340,31,FG,True,700)
s.link('Open Virginia Tech demonstration',SOURCES['S5'][1],770,729,750)
s.link('Additional drift videos (online)',SOURCES['S6'][1],770,780,750);s.done()

s=Slide('02 / The product','Keep the tractor. Make the spray respond.','Trailer-mounted tank + cameras + three independently controlled fixed zones.',note='[0:45–1:10] We already have some cameras, tanks and sprayer hardware. The proposed product combines those components with a controller and independently actuated valves. This original 3D animation is a concept illustration with synthetic canopy states. It shows one side and three vertically stacked zones, pending confirmation of the final layout. The nozzle directions stay fixed, and one chemical is used per operation. Initial scope is vineyard insecticide and fungicide canopy applications; herbicide weed treatment needs a separate target configuration.')
if (O/'sprayer-in-action.mp4').exists():s.movie(O/'sprayer-in-action.mp4',O/'concept-render.png',64,244,1095,550)
else:s.picture(O/'concept-render.png',64,244,1095,550)
s.text('CAMERA\nLooks ahead\n\nCONTROLLER\nEstimates density\n\nVALVES\nGate each zone',1210,270,25,FG,True,325)
s.text('CONCEPT ANIMATION\nNot field-test footage',1200,704,18,ORANGE,False,330);s.done()

s=Slide('03 / AI creativity','A canopy map becomes a timed spray decision.','The AI estimates the target. A calibrated controller determines the allowed application.',note='[1:10–1:40] A vision model separates vine foliage from background and weeds, then produces an occupancy score for upper, middle and lower zones. Visible occupancy is a proxy for canopy density, not a direct measurement of inner leaf area. Tractor speed and the camera-to-nozzle distance let the controller queue the command for the correct location. Each zone switches off at a gap or receives a calibrated output. We will compare trained segmentation with simple green-threshold vision to show whether the AI adds value. Pressure changes remain inside validated limits; independent valves or compatible PWM control are our main zone-level controls.')
for x,num,t,d in [(64,'1','SEE','RGB frames\nFoliage segmentation'),(440,'2','SCORE','Upper / middle / lower\nOccupancy + confidence'),(816,'3','TIME','Speed + lookahead\nMatch nozzle position'),(1192,'4','ACT','Gap → off\nFoliage → calibrated flow')]:
 s.rect(x,285,344,250,PANEL);s.text(num,x+24,303,24,TEAL,True,280);s.text(t,x+24,350,34,FG,True,290);s.text(d,x+24,415,23,MUT,width=295)
s.text('AI value: distinguish vine foliage from green background; adapt to changing light.',70,596,29,GREEN,True,1430)
s.text('Local inference • No cloud required to operate • Log decisions and actual flow',70,693,25,FG,width=1430)
s.text('All functions shown are proposed; no accuracy or latency results claimed.',70,776,19,MUT,width=1430);s.done()

s=Slide('04 / Farm economics','The buyer needs a payback case.','Illustrative annual model for one unit serving 500 unique acres. All dollar inputs are assumptions.',source='Planning model, not a measured result or quote. USD.',note='[1:40–2:10] Consider one unit actually able to serve 500 unique acres across the eligible annual spray program. If those chemicals cost 250 dollars per acre per year and we achieve a 30 percent reduction with equivalent protection, gross savings are 37,500 dollars. Subtract 1,500 dollars of incremental annual maintenance and support and net savings are 36,000 dollars. At an assumed 24,000-dollar purchase price, simple payback is eight months of equivalent annual savings, not a promise of calendar-month cash recovery. The low case in the appendix is much less attractive. These are hypotheses to replace with farm records and trial data.')
s.card(64,280,466,'ELIGIBLE ANNUAL CHEMICAL SPEND','$125,000','500 acres × $250 / acre / year')
s.card(566,280,466,'ASSUMED NET ANNUAL SAVINGS','$36,000','30% reduction, less $1,500 upkeep')
s.card(1068,280,466,'SIMPLE PAYBACK','0.67 years','$24,000 unit / $36,000 net savings',TEAL)
s.text('Savings must come with acceptable coverage and disease / pest control.',70,593,31,GREEN,True,1410)
s.text('No labor, water, fuel or yield gains included. Acreage capacity remains to be demonstrated.',70,694,25,MUT,width=1410);s.done()

s=Slide('05 / First customers','Start where repeated applications matter.','Large vineyard operators and custom applicators with compatible tractors and repeat spray programs.',source='S2: USDA NASS, 2025 Summary, p. 38. Reachable segment is a planning assumption.',note='[2:10–2:30] Our initial buyer is a vineyard operations manager, with the agronomist and equipment manager helping evaluate it. USDA reports 883,000 U.S. grape bearing acres for 2025. That is crop context, not a count of customers or proof that every acre is serviceable. A planning scenario of 100,000 reachable acres divided by 500 acres per machine gives 200 machine equivalents, or 4.8 million dollars of one-time equipment sales at our assumed price. We need local customer interviews, row-fit checks, workload capacity and procurement data to establish a real serviceable market.')
s.card(64,280,466,'U.S. GRAPE BEARING AREA','883,000 acres','2025 reported crop context')
s.card(566,280,466,'REACHABLE-AREA SCENARIO','100,000 acres','Assumption; local fit unvalidated')
s.card(1068,280,466,'IMPLIED EQUIPMENT OPPORTUNITY','$4.8 million','200 unit equivalents × $24,000')
s.text('First sale path: farm pilot → documented results → neighboring growers → dealers.',70,606,30,GREEN,True,1430)
s.text('One unit is not one farm. Capacity, spray windows and fleets determine demand.',70,714,25,MUT,width=1430);s.done()

s=Slide('06 / Competition','Precision spraying is a proven category.','Our proposed advantage must be demonstrated: simpler camera-based hardware and a focused three-zone design.',source='S3: Smart Apply vineyard product page. No competitor price comparison claimed.',note='[2:30–2:55] We are not the first intelligent sprayer. Smart Apply already markets LiDAR-based canopy-responsive control for vineyards. Well-calibrated conventional sprayers and other sensor systems also compete for the same budget. Our hypothesis is that an RGB-camera, three-zone system can offer a serviceable, accessible option for a specific vineyard layout. We do not yet know that it is cheaper or equally capable. Our pilot must establish coverage, reliability, installed cost and service time against alternatives. More detailed control and dealer support are areas incumbents may do better.')
rows=[('OPTION','STRENGTH','OUR RESPONSE'),('Calibrated conventional','Available; familiar to crews','Beat a calibrated baseline'),('Smart Apply / LiDAR','Existing canopy sensing product','Test camera cost and robustness'),('CanopyFlow / proposed','Focused, three-zone camera design','Prove coverage and total cost')]
for j,row in enumerate(rows):
 y=280+j*108;s.rect(64,y,1472,92,PANEL if j%2 else '#233F45')
 for x,w,t in zip([85,540,1040],[420,460,470],row):s.text(t,x,y+23,22 if j else 19,GREEN if j==0 else FG,j==0,w)
s.text('Defensibility to build: local training data, calibration recipes, reliability and farm relationships.',70,752,24,MUT,width=1420);s.done()

s=Slide('07 / Business model','Sell equipment. Earn the next deployment.','Proposed complete trailer unit; tractor excluded. Start with direct farm sales and local service.',note='[2:55–3:20] Our planning price is 24,000 dollars for the complete trailer sprayer, excluding the tractor. At an estimated build and delivery cost of 14,000 dollars, unit gross profit is 10,000 dollars, or about 42 percent. That is before company overhead, research, selling cost and taxes. The cost sheet includes assembly and an initial warranty allowance; supplier quotes are still needed. Ten paid units would mean 240,000 dollars of revenue and 100,000 dollars of gross profit, not net profit or a sales forecast. Core operation is offline; optional service must not block spraying.')
s.card(64,280,466,'PROPOSED SELLING PRICE','$24,000','Complete trailer unit; tractor excluded')
s.card(566,280,466,'ESTIMATED UNIT COST','$14,000','Parts, assembly, delivery, warranty')
s.card(1068,280,466,'UNIT GROSS PROFIT','$10,000','41.7% gross margin; before overhead')
s.text('10 paid units → $240,000 revenue / $100,000 gross profit',70,602,36,GREEN,True,1430)
s.text('Planning scenario only. Validate quotes, installation time and willingness to pay.',70,711,25,MUT,width=1430);s.done()

s=Slide('08 / Farm partnership','Fund a pilot. Receive two units.','Proposed $60,000 founding-farm sponsorship, with milestones and a bounded delivery commitment.',note='[3:20–3:45] We propose a 60,000-dollar founding-farm sponsorship. In exchange, the farm receives two pilot units after agreed acceptance tests, a defined first-season support package and a joint results report. The farm also provides trial acreage, operator time, eligible chemical records and agronomic oversight. This is development sponsorship, not equity or guaranteed savings. The draft budget is 28,000 dollars for two builds, 14,000 for engineering, 10,000 for validation and 8,000 contingency. The agreement needs milestones, cost-overrun terms, data rights and a remedy if acceptance is not achieved. No unlimited free units or blanket exclusivity.')
for x,t,d in [(64,'THE FARM FUNDS','$60,000 development pilot\nTrial access + operator time\nBaseline records + agronomist'),(566,'THE FARM RECEIVES','Two included pilot units*\nDefined first-season support\nMeasured results and early input'),(1068,'WE DELIVER','Bench + water-only testing\nControlled vineyard evaluation\nAcceptance report + next-build plan')]:
 s.rect(x,280,466,354,PANEL);s.text(t,x+26,310,23,GREEN,True,414);s.text(d,x+26,381,26,FG,width=414)
s.text('*Proposed terms: delivery after agreed acceptance; ownership and remedies set in contract.',70,687,23,MUT,width=1420)
s.text('Development capital tied to evidence, not an untested savings guarantee.',70,752,27,TEAL,True,1420);s.done()

s=Slide('09 / Validation','Lower use only counts if protection holds.','A staged pilot turns the savings story into evidence.',source='S4: application must follow the product label. Targets below are proposed acceptance goals.',note='[3:45–4:15] First we test with water: timing, shutoff, pressure stability and failure behavior. Then we compare a calibrated baseline with variable output in randomized or matched replicated vineyard blocks across different canopy stages. We measure actual liters per acre, upper and lower leaf coverage, inside-canopy deposition, missed targets and field uptime. Our proposed economic target is at least 20 percent less eligible spray volume; an agronomist must set the coverage thresholds and acceptable disease and pest non-inferiority margin before trials. Disease outcomes require a spray program and season, not one demonstration. Camera failure closes the valves and alerts the driver; normal protection resumes through a deliberate operator-controlled procedure.')
for x,n,t,d in [(64,'01','BENCH + WATER','Valve timing, pressure stability\nLookahead and stop response'),(566,'02','FIELD COVERAGE','Replicated baseline comparisons\nInner / outer and leaf undersides'),(1068,'03','SEASONAL OUTCOMES','Chemical use + crop protection\nReliability + actual payback')]:
 s.rect(x,280,466,300,PANEL);s.text(n,x+25,305,28,TEAL,True,400);s.text(t,x+25,363,26,FG,True,415);s.text(d,x+25,429,23,MUT,width=415)
s.text('Proposed targets: ≥20% eligible-volume reduction + agronomist-approved protection.',70,634,29,GREEN,True,1420)
s.text('No field savings, detection accuracy, uptime or crop-outcome results claimed today.',70,749,24,MUT,width=1420);s.done()

s=Slide('10 / Execution','Hardware on hand. Integration comes next.','Hardware on hand is a head start; field performance is the milestone.',note='[4:15–4:40] We have some cameras, tanks and spray hardware, as reported by the team. We are not yet claiming an integrated working product or customer commitments. A proposed first 90 days covers the component audit, mechanical integration, vision baseline, timing controller and water-only validation. Field trials then follow the crop calendar and farm access. Before promising a delivery date, we must identify a named technical lead, fabrication capability, field-test partner and agronomist. Our first scope is one side with three zones; both-side operation and commercial throughput need their own validation.')
for x,t,d in [(64,'ON HAND','Cameras\nTanks\nSprayer components'),(566,'BUILD NEXT','Inventory and fit checks\nVision + valve integration\nBench and water testing'),(1068,'PROVE NEXT','Compatible row geometry\nCoverage and seasonal control\nFarmer willingness to pay')]:
 s.rect(x,280,466,350,PANEL);s.text(t,x+26,308,25,GREEN,True,412);s.text(d,x+26,385,27,FG,width=412)
s.text('First 90 days: proposed engineering phase. Seasonal trials follow crop timing.',70,699,28,TEAL,True,1420)
s.text('Confirm team roles, hardware specifications and host farm before making commitments.',70,765,20,MUT,width=1420);s.done()

s=Slide('11 / The ask','Help us prove the savings in your vineyard.','Seeking one founding-farm partner for a milestone-based development pilot.',note='[4:40–5:00] Our ask is one founding-farm partner for a proposed 60,000-dollar pilot and access to a real vineyard spray program. That supports two units, independent measurements and a defined acceptance decision. CanopyFlow aims to help farms spend less material on gaps and match output to the plant target. Our next milestone is clear: prove less use with acceptable crop protection and an investment case the grower can verify.')
s.text('$60,000',70,282,100,GREEN,True,1000)
s.text('Two included pilot units.\nOne measured path to a repeatable product.',75,433,41,FG,True,1400)
s.text('SEE THE CANOPY. MATCH THE SPRAY.',75,675,39,TEAL,True,1400)
s.text('Temporary name • Proposed commercial terms • Seeking a pilot, not claiming field results',75,770,20,MUT,width=1420);s.done()

s=Slide('Appendix A / Financial sensitivity','What if savings are smaller?','Same $24,000 purchase price and $1,500 incremental annual upkeep; chemical-only benefits.',note='All scenarios are illustrative and assume unchanged eligible treatment program and acceptable crop protection. Acres are unique annual acres served, not acres multiplied by passes. Cost per acre is annual eligible chemical product cost across those passes. Savings percentage is a reduction in chemical product use/cost at unchanged unit price, not just a reduction in water. Zero or negative net savings means no simple payback.')
rows=[('SCENARIO','ACRES','$/AC/YR','REDUCTION','NET / YEAR','PAYBACK'),('Low',250,'$150','15%','$4,125','5.82 years'),('Base',500,'$250','30%','$36,000','0.67 years'),('High',750,'$350','40%','$103,500','0.23 years')]
for j,row in enumerate(rows):
 y=275+j*101;s.rect(64,y,1472,87,PANEL if j%2 else '#233F45')
 for x,w,t in zip([84,340,525,770,1040,1300],[220,140,200,220,220,215],row):s.text(str(t),x,y+27,21 if j else 17,GREEN if j==0 else FG,j==0,w)
s.text('Base net = 500 × $250 × 30% − $1,500 = $36,000 / year',70,722,30,GREEN,True,1400)
s.text('Break-even reduction for a 2-year payback in the base farm: 10.8%.',70,777,21,MUT,width=1400);s.done()

s=Slide('Appendix B / Cost to deliver','A complete-unit cost target—not supplier quotes.','Two-unit pilot budget includes the included units once; existing hardware does not erase replacement cost.',note='Estimated unit build cost: chassis and tank 3,500; pump, plumbing and three-zone valves 2,500; cameras and edge compute 1,500; power, sensors and enclosure 1,200; fabrication and assembly 3,000; delivery, installation and initial warranty reserve 2,300. Total 14,000 dollars. Existing components need inventory and replacement-value confirmation. No supplier quotations obtained. Cost target may change if air assist, greater throughput or two-sided coverage is required. Pilot budget is separate from a sale-price scenario.')
items=[('Chassis + tank','$3,500'),('Pump, plumbing + valves','$2,500'),('Cameras + edge compute','$1,500'),('Power, sensors + enclosure','$1,200'),('Fabrication + assembly','$3,000'),('Delivery, installation + warranty','$2,300')]
for i,(t,v) in enumerate(items):y=266+i*73;s.text(t,75,y,26,FG,width=820);s.text(v,920,y,27,GREEN,True,250)
s.rect(1200,268,335,443,PANEL);s.text('PILOT USE OF FUNDS',1224,293,18,TEAL,True,290);s.text('2 builds    $28k\nEngineering $14k\nValidation  $10k\nContingency  $8k',1224,360,23,FG,width=290)
s.text('Unit total: $14,000',75,747,34,GREEN,True,1000);s.done()

s=Slide('Appendix C / Technical questions','Density informs flow; pressure needs limits.','A common pressure line does not provide three independent pressure settings.',source='Engineering proposal. S4 and S7 inform application constraints.',note='Pressure and flow are coupled. For a fixed hydraulic nozzle, flow is approximately proportional to the square root of pressure, so doubling flow can require roughly quadrupling pressure. Use nozzle-specific curves, calibrated recipes and pressure limits. A shared pump can hold a regulated pressure while individual compatible valves or PWM set zone output. If true independent pressures are necessary, add regulators and sensors per branch. Visible foliage occupancy is not full canopy density; multi-view sensing or depth may be needed. Lookahead delay is distance divided by speed, minus measured actuation and fluid delays. Example: 1 meter lookahead at 1.5 meters per second is 0.67 seconds before subtracting delay. Reject out-of-range speed or insufficient lookahead. No actual pressure setpoints are proposed without the nozzle and product label.')
for y,t,d in [(275,'Zone-level control','Independent on/off valves; compatible PWM for calibrated flow.'),(400,'Pressure management','Regulated manifold; branch regulation if independent pressure is required.'),(525,'Camera-to-nozzle timing','Queue commands using measured speed, lookahead and valve / fluid delay.'),(650,'Dense-canopy challenge','Validate inner and underside coverage; air assist may be necessary.')]:
 s.text(t,75,y,28,GREEN,True,600);s.text(d,680,y,25,FG,width=820)
s.text('Nozzle and pump specifications are still needed to finalize the hydraulic design.',75,786,20,MUT,width=1400);s.done()

s=Slide('Appendix D / Failure modes','The driver remains in control.','Fault behavior and application limits are part of the product design.',note='Planned controls, not implemented results: low-confidence image, obscured lens or stale frames stop automated spraying and alert the driver; any return to a calibrated conventional mode requires deliberate operator action and approved settings. Low or high flow, pressure loss and stuck-open valve require monitored shutdown and isolation. Headlands and stopped tractor close valves. Validate command watchdog, electrical loss, speed bounds and emergency stop. Keep records of actual delivered flow, not just commanded valve state. Green weeds behind the vines require segmentation, geometry and confidence checks. Herbicide use must not reuse crop-canopy targeting.')
for y,t,d in [(277,'Dirty lens / uncertain image','Close valves + alert; deliberate operator-controlled recovery.'),(393,'Stuck valve / flow mismatch','Compare command with measured flow; isolate and stop.'),(509,'Headland / stopped tractor','Disable spray using row state, speed bounds and operator override.'),(625,'Wrong green target','Separate vine foliage from weeds; test shadows, dust and backlight.')]:
 s.text(t,75,y,27,GREEN,True,590);s.text(d,695,y,25,FG,width=800)
s.text('One chemical per run. Cleanout and product-label requirements remain essential.',75,767,23,MUT,width=1420);s.done()

s=Slide('Appendix E / Evidence','What is sourced—and what is still a hypothesis?','External results support the category. They do not validate this product.',note='USDA ARS Chen et al. 2013 studied a laser-guided variable-rate sprayer in an apple orchard, not our RGB-camera design in grapes. It reported 47–73 percent spray-volume reduction versus a constant-rate comparison with comparable inside-canopy deposition quality. Do not present the upper bound as our expected savings. Our 30 percent base-case chemical-cost reduction is a planning assumption. Actual savings depend on label-consistent application, concentration, crop stage, gaps, coverage, climate and equipment. NASS acreage is reported crop context, not a customer count. Smart Apply information is vendor-stated competitive context.')
s.text('SOURCED',75,278,24,TEAL,True,650)
s.text('47–73% spray-volume reduction in a\nlaser-guided apple-orchard study. [S1]\n\n883,000 U.S. grape bearing acres\nin the 2025 NASS summary. [S2]',75,337,27,FG,width=695)
s.text('NOT YET PROVEN FOR CANOPYFLOW',850,278,24,ORANGE,True,680)
s.text('30% chemical-cost reduction\n$24,000 selling price / $14,000 cost\n500 acres served per unit\nDetection accuracy and field uptime\nEquivalent crop protection',850,337,27,FG,width=680)
s.text('Team-reported: some cameras, tanks and sprayer hardware are already on hand.',75,743,24,MUT,width=1400);s.done()

for group in [['S1','S2','S3','S4'],['S5','S6','S7']]:
 s=Slide('Appendix F / References','Source links for judge questions.','Primary research, official crop statistics and clearly identified vendor / educational sources.',note='Links checked through source pages during preparation. Some embedded video hosts could not be played from the research environment. See media-cues.md for playback status and fallback narration. Research prepared November 14, 2026, America/Los_Angeles.')
 for i,key in enumerate(group):
  name,url=SOURCES[key];y=265+i*126;s.text(key,75,y,23,GREEN,True,80);s.link(name,url,173,y,1330);s.text(url,173,y+43,17,MUT,width=1300)
 s.done()

short_scripts=[
'[0:00–0:20] Every gap in a vine canopy is a chance to save spray. We are developing CanopyFlow: a tractor-towed sprayer that sees foliage and matches output to the plant target. We are seeking a farm partner to prove the savings without compromising crop protection.',
'[0:20–0:45, including 8-second clip] Constant output can spray through canopy gaps. [Play clip.] This university water-only orchard demonstration illustrates the need to match application to the target. It is not our machine, grape footage or a measurement of waste.',
'[0:45–1:10, including 8-second animation] Our proposed trailer combines a single tank, cameras and three fixed spray zones. [Play animation.] Each zone switches independently; the nozzles do not move. This original concept animation uses synthetic canopy states, not live AI or prototype test results.',
'[1:10–1:40] The proposed AI separates vine foliage from background and estimates visible density in upper, middle and lower zones. The controller uses ground speed and camera lookahead to time each valve. Gaps switch off; foliage receives calibrated output. We will compare learned segmentation against simple green detection. The AI must add measurable value under shadows, weeds and changing light. Control runs locally.',
'[1:40–2:10] Here is an illustrative business case, not a result. One unit serves 500 unique acres with 250 dollars per acre in annual eligible chemicals. A 30 percent reduction saves 37,500 dollars. After 1,500 dollars of annual upkeep, net savings are 36,000 dollars. At a proposed 24,000-dollar purchase price, simple payback is 0.67 years. Smaller savings can make payback much longer.',
'[2:10–2:30] Our first customers are large vineyards and custom applicators. USDA reports 883,000 U.S. grape bearing acres for 2025. Our reachable-acre scenario is an assumption, not a customer count. We will establish actual demand through local interviews, equipment-fit checks and pilot conversion.',
'[2:30–2:55] Precision spraying already exists. Smart Apply markets LiDAR-based vineyard control, and well-calibrated conventional sprayers are also competitors. Our proposed difference is a focused camera-based, three-zone design. We must demonstrate competitive installed cost, serviceability and coverage. We are not yet claiming lower cost or better performance than existing products.',
'[2:55–3:20] The proposed complete trailer sells for 24,000 dollars, excluding the tractor. Our estimated build-and-delivery cost is 14,000 dollars, leaving 10,000 dollars gross profit before overhead and research. Those are planning assumptions awaiting quotes. We would start with direct farm sales and local service, then expand through referrals and dealers.',
'[3:20–3:45] We propose a 60,000-dollar founding-farm sponsorship. The farm receives two included pilot units after agreed acceptance, defined support and a results report. Funding covers the builds, engineering, validation and contingency. The farm contributes trial access and operational records. Milestones and remedies must be agreed; this is development sponsorship, not guaranteed savings.',
'[3:45–4:15] Lower use only counts if protection holds. We start with bench and water tests, then replicated comparisons against a calibrated baseline. We measure actual chemical use, inside-canopy coverage, reliability and seasonal pest or disease outcomes. Our proposed target is at least 20 percent less eligible spray volume, with agronomist-approved protection criteria. Product labels govern application. Faults stop automated spraying and alert the driver.',
'[4:15–4:40] We already have some cameras, tanks and spray hardware. The next step is integration, not a production-readiness claim. A proposed first 90 days covers the component audit, controller and water testing; seasonal trials follow the crop calendar. We still need confirmed engineering roles, hardware specifications and a host farm.',
'[4:40–5:00] We are seeking one founding farm for a milestone-based pilot: two units and a measured decision about deployment. CanopyFlow aims to spend less spray on gaps and match output to the crop. Help us prove the savings in your vineyard.'
]
for n,script in enumerate(short_scripts):
 notes[n]['script']=script;R.slides[n].notes_slide.notes_text_frame.text=script
PDF.save();R.save(O/'CanopyFlow-pitch.pptx')
(O/'speaker-notes.md').write_text('# CanopyFlow — five-minute speaker script\n\nWorking name and all proposed financial terms are editable. Slides 1–12 are the pitch; later slides are Q&A backup. Timing includes short media playback.\n\n'+'\n\n'.join(f"## {n['slide']}. {n['title']}\n\n{n['script']}" for n in notes))
(O/'sources.json').write_text(json.dumps(SOURCES,indent=2))

wb=Workbook();a=wb.active;a.title='Farm ROI'
rows=[['CANOPYFLOW — EDITABLE PLANNING MODEL','Value','Units / interpretation'],['All blue inputs are assumptions; no farm performance data.'],['Unique acres served annually',500,'acres; do not multiply by spray passes'],['Eligible chemical cost per acre per year',250,'USD; annual chemical product cost, excluding labor / water'],['Chemical product reduction',.30,'fraction; equivalent control required'],['Incremental annual upkeep',1500,'USD; maintenance / support cost to farm'],['Purchase price',24000,'USD; complete trailer, tractor excluded'],['Gross annual chemical saving','=B3*B4*B5','USD'],['Net annual saving','=B8-B6','USD'],['Simple payback, years','=IF(B9>0,B7/B9,"No payback")','years; undiscounted, pre-tax'],['Equivalent annualized months','=IF(B9>0,B10*12,"No payback")','not a claim about seasonal cash timing'],['Reduction needed for 2-year payback','=(B7/2+B6)/(B3*B4)','fraction; constant program and unit chemical price'],[],['Exclude unproven labor, fuel, water and yield benefits.'],['Lower water volume alone does not prove lower chemical cost.']]
for row in rows:a.append(row)
for r in [5,12]:a.cell(r,2).number_format='0.0%'
for r in [4,6,7,8,9]:a.cell(r,2).number_format='"$"#,##0'
for r in [10,11]:a.cell(r,2).number_format='0.00'
b=wb.create_sheet('Sensitivity')
for row in [['Scenario','Acres','Annual chemical $/acre','Reduction','Annual upkeep','Price','Net annual saving','Payback years'],['Low',250,150,.15,1500,24000,'=B2*C2*D2-E2','=IF(G2>0,F2/G2,"No payback")'],['Base',500,250,.30,1500,24000,'=B3*C3*D3-E3','=IF(G3>0,F3/G3,"No payback")'],['High',750,350,.40,1500,24000,'=B4*C4*D4-E4','=IF(G4>0,F4/G4,"No payback")']]:b.append(row)
for r in range(2,5):b.cell(r,4).number_format='0%';b.cell(r,7).number_format='"$"#,##0';b.cell(r,8).number_format='0.00'
c=wb.create_sheet('Unit economics')
for row in [['Item','USD / unit','Status'],['Chassis + tank',3500,'Budget assumption'],['Pump, plumbing + valves',2500,'Budget assumption'],['Cameras + edge computer',1500,'Budget assumption'],['Power, sensors + enclosure',1200,'Budget assumption'],['Fabrication + assembly',3000,'Budget assumption'],['Delivery, installation + initial warranty',2300,'Budget assumption'],['Total build cost','=SUM(B2:B7)','Not a supplier quote'],['Proposed sale price',24000,'Assumption; tractor excluded'],['Gross profit per unit','=B9-B8','Before corporate overhead'],['Gross margin','=B10/B9','fraction'],['Paid-unit scenario',10,'Not orders or a forecast'],['Equipment revenue','=B9*B12','USD'],['Total paid-unit cost','=B8*B12','USD'],['Gross profit','=B13-B14','USD; not net income']]:c.append(row)
c['B11'].number_format='0.0%'
d=wb.create_sheet('Pilot budget')
for row in [['Use of funds','USD','Notes'],['Two included units',"='Unit economics'!B8*2",'Included once; no separate free-unit cost'],['Engineering',14000,'Integration, software and project labor'],['Validation',10000,'Field measurements and agronomic oversight'],['Contingency',8000,'Planning reserve'],['Total sponsorship','=SUM(B2:B5)','Non-equity development sponsorship'],['Milestone 1 / 40%','=B6*40%','Signed scope + component audit'],['Milestone 2 / 40%','=B6*40%','Bench and water-only acceptance'],['Milestone 3 / 20%','=B6*20%','Agreed field acceptance / remedy decision']]:d.append(row)
e=wb.create_sheet('Market scenario')
for row in [['Metric','Value','Source / limitation'],['U.S. grape bearing acres, 2025',883000,SOURCES['S2'][1]+' | p. 38'],['Reachable acres',100000,'Assumption, not a measured serviceable market'],['Acres per machine',"='Farm ROI'!B3",'Seasonal workload capacity must be validated'],['Machine equivalents','=B3/B4','Not number of farms'],['One-time equipment revenue',"=B5*'Unit economics'!B9",'Scenario; not recurring annual revenue']]:e.append(row)
f=wb.create_sheet('Calculated snapshot')
for row in [['Metric','Base-case static value','Purpose'],['Gross saving',37500,'Readable before spreadsheet recalculation'],['Net saving',36000,'Cross-checked in Python'],['Payback years',24000/36000,'Cross-checked in Python'],['Payback equivalent months',8,'Annualized only'],['Gross margin',10000/24000,'Before corporate overhead'],['Pilot funding',60000,'Includes two units'],['Low-case payback years',24000/4125,'Low-case net = 4,125 USD'],['Two-year break-even reduction',.108,'Base farm assumptions']]:f.append(row)
for sh in wb:
 sh.freeze_panes='B2';sh.auto_filter.ref=sh.dimensions
 for cell in sh[1]:cell.fill=PatternFill('solid',fgColor='17343C');cell.font=Font(name='Calibri',bold=True,color='FFFFFF',size=12)
 for row in sh.iter_rows(min_row=2):
  for cell in row:
   cell.alignment=Alignment(vertical='top',wrap_text=True)
   cell.font=Font(name='Calibri',size=11,color='1672B6' if cell.column>1 and cell.data_type!='f' and isinstance(cell.value,(int,float)) else '18363C')
 sh.column_dimensions['A'].width=46
 for col in 'BCDEFGH':sh.column_dimensions[col].width=27 if col!='C' else 63
 sh.row_dimensions[1].height=34
 for r in range(2,sh.max_row+1):sh.row_dimensions[r].height=32
wb.save(O/'CanopyFlow-business-model.xlsx')
print('Built',len(R.slides),'slides, PDF, notes and XLSX')
