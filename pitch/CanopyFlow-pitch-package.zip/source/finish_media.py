from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,subprocess
W=Path('/workspace/work');O=Path('/workspace/output')
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
states=json.loads((W/'states.json').read_text())
for i,v in enumerate(states,1):
 im=Image.open(W/f'frames/{i:04}.png').convert('RGB');d=ImageDraw.Draw(im)
 d.rectangle((0,0,960,69),fill='#101F25');d.text((23,14),'CANOPYFLOW / THREE FIXED SPRAY ZONES',font=ImageFont.truetype(BOLD,19),fill='#F2F1E9')
 d.text((23,43),'3D CONCEPT  •  Synthetic density states, not live AI or measured application',font=ImageFont.truetype(FONT,13),fill='#A9BDBD')
 d.rectangle((0,442,960,540),fill='#101F25')
 for j,k in enumerate([2,1,0]):
  x=24+j*315;on=v[k]>0;label=['LOWER','MIDDLE','UPPER'][k]
  d.text((x,455),f'{label}  {"ON" if on else "OFF / GAP"}',font=ImageFont.truetype(BOLD,16),fill='#9BE3A3' if on else '#FFBA72')
  d.rectangle((x,486,x+267,498),fill='#355057')
  if on:d.rectangle((x,486,x+int(267*v[k]),498),fill='#51CFCA')
  d.text((x,507),f'Illustrative occupancy {v[k]:.0%}',font=ImageFont.truetype(FONT,12),fill='#A9BDBD')
 im.save(W/f'frames/{i:04}.png')
 if i==73:im.save(O/'concept-render.png')
subprocess.run(['ffmpeg','-y','-framerate','12','-i',str(W/'frames/%04d.png'),'-an','-c:v','libx264','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(O/'sprayer-in-action.mp4'),'-loglevel','error'],check=True)
print('Encoded original concept video:',len(states)/12,'seconds')
