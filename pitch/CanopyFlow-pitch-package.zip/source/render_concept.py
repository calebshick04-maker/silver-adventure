import bpy, math, random, os, json
from mathutils import Vector
random.seed(7)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
sc=bpy.context.scene
sc.render.engine='BLENDER_WORKBENCH'
sc.display.shading.light='STUDIO';sc.display.shading.studiolight_rotate_z=0.5
sc.display.shading.color_type='MATERIAL';sc.display.shading.show_shadows=True
sc.display.shading.show_cavity=True;sc.display.shading.cavity_type='BOTH'
sc.display.shading.background_type='WORLD';sc.world.color=(0.76,0.81,0.79)
sc.render.resolution_x=960;sc.render.resolution_y=540;sc.render.resolution_percentage=100
sc.render.image_settings.file_format='PNG';sc.render.fps=12
sc.view_settings.view_transform='Standard'
def mat(n,c):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);return m
green=mat('CanopyFlow green',(0.04,.32,.20));white=mat('Tank ivory',(.88,.91,.86));black=mat('Rubber',(.035,.045,.045));metal=mat('Steel',(.18,.23,.24));red=mat('Tractor coral',(.8,.24,.12));glass=mat('Cab glazing',(.21,.44,.48));dirt=mat('Vineyard soil',(.63,.51,.34));cyan=mat('Illustrative spray',(.24,.85,.88));orange=mat('Camera amber',(.98,.59,.12));purple=mat('Grapes',(.23,.12,.34))
leaves=[mat('Foliage '+str(i),(.10+i*.018,.28+i*.035,.07+i*.012)) for i in range(6)]
rig=bpy.data.objects.new('TRACTOR_AND_TRAILER',None);sc.collection.objects.link(rig)
def cube(n,loc,scale,m,parent=None):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m);o.parent=parent;return o
def cyl(n,loc,r,depth,m,rot=(0,0,0),parent=None):
 bpy.ops.mesh.primitive_cylinder_add(vertices=24,radius=r,depth=depth,location=loc,rotation=rot);o=bpy.context.object;o.name=n;o.data.materials.append(m);o.parent=parent;return o
def ball(n,loc,scale,m,parent=None):
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=1,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;o.data.materials.append(m);o.parent=parent;return o
cube('Ground',(0,0,-.13),(48,24,.2),dirt)
for yy in [2.3,7.5]:
 for x in range(-18,20,3):
  cyl('Trellis post',(x,yy,1.5),.055,3,metal)
 for z in [1.25,2,2.8]:cyl('Trellis wire',(0,yy,z),.014,40,metal,(0,math.pi/2,0))
 for x in range(-18,20):
  if yy==2.3 and (x in [-3,-2,3,4]):continue
  cyl('Vine trunk',(x,yy,.65),.055,1.4,metal)
  for zi,z in enumerate([1.35,2.05,2.75]):
   if yy==2.3 and zi==2 and -7<x<0:continue
   if yy==2.3 and zi==0 and 6<x<10:continue
   for k in range(4):ball('Leaf cluster',(x+random.uniform(-.5,.5),yy+random.uniform(-.2,.2),z+random.uniform(-.18,.18)),(.43,.28,.31),random.choice(leaves))
  if x%2==0:
   for k in range(4):ball('Grape bunch',(x+.18,yy-.30,1.2+k*.09),(.08,.08,.11),purple)
cube('Trailer chassis',(-1,0,.70),(3.3,1.45,.22),green,rig)
cube('Drawbar',(1,0,.65),(1.6,.17,.17),metal,rig)
cyl('Horizontal single tank',(-1,0,1.44),.68,2.5,white,(0,math.pi/2,0),rig)
cyl('Tank cap',(-1.1,0,2.12),.19,.12,green,parent=rig)
for x in [-1.85,-.3]:
 for y in [-.52,.52]:cube('Tank restraint',(x,y,1.4),(.1,.08,1.3),green,rig)
for y in [-.89,.89]:
 cyl('Trailer tyre',(-1,y,.52),.49,.27,black,(math.pi/2,0,0),rig);cyl('Trailer hub',(-1,y*1.17,.52),.24,.04,white,(math.pi/2,0,0),rig)
cube('Spray tower',(-2.5,.62,1.83),(.17,.18,2.5),metal,rig)
for z in [1.35,2.05,2.75]:
 cyl('Fixed nozzle',(-2.5,.81,z),.085,.23,orange,(math.pi/2,0,0),rig)
cube('Edge compute',(-2.18,-.57,1.0),(.44,.27,.40),black,rig)
cube('Camera lookahead mast',(-.8,.68,2.6),(.09,.09,1),metal,rig)
cube('RGB camera',(-.8,.71,3.15),(.28,.2,.17),orange,rig)
cyl('Camera lens',(-.8,.84,3.15),.062,.06,black,(math.pi/2,0,0),rig)
cube('Tractor body',(3.0,0,1.0),(2.2,1.25,.58),red,rig)
cube('Hood',(3.8,0,1.44),(1.0,1.12,.5),red,rig)
cube('Cab',(2.4,0,1.91),(1.05,1.08,1.25),glass,rig)
cube('Cab roof',(2.4,0,2.57),(1.3,1.35,.13),red,rig)
cyl('Exhaust',(3.5,.43,2.02),.045,.85,black,parent=rig)
for x,r in [(2,.7),(4,.45)]:
 for y in [-.78,.78]:
  cyl('Tractor tyre',(x,y,r),r,.34,black,(math.pi/2,0,0),rig);cyl('Tractor hub',(x,y*1.26,r),r*.48,.04,white,(math.pi/2,0,0),rig)
sprays=[]
for zi,z in enumerate([1.35,2.05,2.75]):
 group=[]
 for k in range(46):
  t=random.random();o=ball('Water illustration zone '+str(zi+1),(-2.5+random.uniform(-.18,.18)*t,.96+t*1.18,z+random.uniform(-.17,.17)*t),(.02,.035,.02),cyan,rig);group.append(o)
 sprays.append(group)
bpy.ops.object.camera_add(location=(-10,-11,7.7));cam=bpy.context.object;sc.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=14.8;cam.data.lens=44
def aim(p):cam.rotation_euler=(Vector(p)-cam.location).to_track_quat('-Z','Y').to_euler()
states=[]
os.makedirs('/workspace/work/frames',exist_ok=True)
for frame in range(1,97):
 sc.frame_set(frame);x=-5+(frame-1)*.125;rig.location.x=x
 target=x-2.5
 # Synthetic canopy occupancy used ONLY to illustrate the control concept.
 gap=(-3.5<target<-1.5) or (2.5<target<4.5)
 vals=[0 if gap else .78,0 if gap else .91,0 if gap or -7<target<0 else .64]
 for zi,g in enumerate(sprays):
  for k,o in enumerate(g):o.hide_render=vals[zi]==0 or k>vals[zi]*46
 cam.location=(x-9,-11,7.7);aim((x-.1,.65,1.2))
 states.append(vals)
 if frame==73:
  sc.render.filepath='/workspace/output/concept-render.png';bpy.ops.render.render(write_still=True)
  bpy.ops.wm.save_as_mainfile(filepath='/workspace/output/sprayer-concept.blend')
 sc.render.filepath=f'/workspace/work/frames/{frame:04}.png';bpy.ops.render.render(write_still=True)
json.dump(states,open('/workspace/work/states.json','w'))
